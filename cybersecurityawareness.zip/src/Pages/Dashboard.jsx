import React from 'react'
import AuthMiddleware from '../Components/AuthMiddleware'

const Dashboard = () => {
   AuthMiddleware();


  return (
    <div className="pt-5 mb-5 text-center">
        <h3 className='fw-bolder'>Dashboard</h3>
    </div>
  )
}

export default Dashboard