import React from 'react'

const CustomAlert = ({ message, alertStyle }) => {
  return (
    <>
        <div className={`alert ${alertStyle}`}>
            {message}
        </div>
    </>
  )
}

export default CustomAlert